Game of Stools
